# Guidance for coding agents

- Treat the official Telegram Serverless PDF as the platform API authority.
- Only use documented `sdk`, `sdk/db`, and `sdk/fetch` imports, and relative imports with explicit `.js` extensions.
- Runtime code belongs under `tgcloud/handlers/`, `tgcloud/lib/`, `tgcloud/endpoints/`, or `tgcloud/schema.js`.
- The bot uses a fresh Telegram Serverless database; do not add old DB imports or data migrations.
- Do not claim tests passed unless actually run; distinguish static checks from platform tests.
- Review database changes with `npx tgcloud diff` and `npx tgcloud migrate`; never assume push changes the DB.
- The platform schema has no foreign-key enforcement. Use unique constraints and validate relationships in code.
- The official documentation supplied with the project should be checked before adding APIs, libraries, timers, or transaction assumptions.
