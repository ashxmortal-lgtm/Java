# Feature status (merged package)

Status labels describe the source code in this ZIP; they are not live-runtime test results.

| Feature | Status | Notes |
|---|---|---|
| Registration / starter shinobi | Present, not runtime-tested | `/start` and user initialization |
| Main menu / profile / balance | Present, not runtime-tested | Inline callbacks wired in `callback_query.js` |
| Daily rewards | Present, needs concurrency hardening | Concurrent claims need atomic conditional update review |
| Shinobi store / equip / purchase | Present, needs transaction hardening | Multi-step debit/grant not transactional |
| Patrol | Present, needs concurrency review | Due patrols complete on later interaction; no background scheduler |
| Group economy toggle | Present, owner config required | `OWNER_TELEGRAM_ID` defaults to 0 |
| Pet inventory / purchase / equip | Present, needs transaction hardening | Pet activity loop not implemented |
| Kill / rob / protect / Byakugan | Present, needs concurrency and authorization review | Reply-based target commands |
| Basic study/todo tables | Schema only | No complete study handlers |
| Hourly quiz tables | Schema only | No scheduler/auto-poster |
| XOXO tables | Schema only | No full game implementation |
| Full map / properties | Not included | Not ported from Python source |
| Bank / special store / nametags | Not included | Not ported from Python source |
| Full Python feature parity | Not achieved | This package merges the two JS ZIPs only |

## Verification performed for this package

- JavaScript syntax checks (`node --check`) — see `TEST_REPORT.md`.
- Relative import target existence and schema export references — see `TEST_REPORT.md`.
- Not performed: live Serverless execution, actual schema migration, Telegram API integration, concurrency tests, or end-to-end game tests.
