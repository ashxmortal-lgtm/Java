# FROZEN Bot — Unified Telegram Serverless JavaScript Project

This package merges `stage3-full.zip` with the feature modules from `final-remaining.zip`. It is a unified **foundation**, not a claim that every feature from the old Python bot has been ported.

## Included commands/features

- `/start`, `/awwsheesh`, `/menu`, `/balance`, `/bal`, `/profile`
- `/daily`, `/claim`
- `/shinobis`, `/shinobi_store`, `/buy_shinobi <id>`, `/buy_chakra`, `/equip <id>`
- `/patrol` with due-time completion on later interactions
- `/economy` owner-only group toggle
- `/pets`, `/buy_pet axofly`, `/buy_pet capycorn`, `/equip_pet <pet>`
- `/kill` and `/rob` by replying to a user's message; `/protect`; `/byakugan` by reply
- Fresh schema declarations for pets, basic study/todos, hourly quiz storage, and XOXO storage. Those tables do not mean the corresponding full feature logic is implemented.

## Project layout

```text
tgcloud/
  handlers/
    message.js
    callback_query.js
  lib/
    combat.js
    economy.js
    extraCommands.js
    format.js
    keyboards.js
    patrol.js
    permissions.js
    pets.js
    shinobi.js
    shinobiData.js
    users.js
    config.js
  schema.js
```

## Before deployment

1. Set `OWNER_TELEGRAM_ID` in `tgcloud/lib/config.js` to the owner's numeric Telegram ID. The default `0` intentionally disables owner recognition.
2. Use a clean Telegram Serverless project/bot database as intended. This package does not import or migrate old database records.
3. Install/use the Telegram Serverless CLI as described by the official documentation and link the project to the intended bot.
4. Review `npx tgcloud diff` and the proposed schema changes before applying anything.
5. Run `npx tgcloud push`, then `npx tgcloud migrate` and review/confirm the migration prompts. Deploying code and changing the database are separate operations.
6. Test with `npx tgcloud run handlers/message '{ chat: { id: 1, type: "private" }, from: { id: 123, first_name: "Test" }, text: "/start" }'` using the CLI's supported JSON5 syntax.

## Important compatibility/security notes

- Only files inside `tgcloud/` are deployed by the platform; root docs/config are local project files.
- Runtime imports use the documented `sdk` and `sdk/db` modules plus relative `.js` imports.
- The platform documentation says database operations are asynchronous and the runtime has no foreign keys. Relationships are therefore enforced in application logic.
- The current platform docs do not document a transaction API. Multi-step purchase/combat operations still need runtime-level testing and further hardening before production use.
- This project has not been run against a live Telegram Serverless bot or its database in this environment. Static syntax checks are not a substitute for runtime integration tests.

## Not yet implemented fully

The source packages explicitly leave full map/property ownership, full study portal, hourly quiz scheduler/posting loop, full XOXO game logic, bank, special store, pet activities, and other legacy Python modules for later stages. See `FEATURE_STATUS.md`.
