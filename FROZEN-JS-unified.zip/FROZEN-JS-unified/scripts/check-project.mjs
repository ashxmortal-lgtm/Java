import { readdir, readFile, access } from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve('tgcloud');
const jsFiles = [];
async function walk(dir) {
  for (const ent of await readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) await walk(full);
    else if (ent.name.endsWith('.js')) jsFiles.push(full);
  }
}
await walk(root);
let failures = 0;
for (const file of jsFiles) {
  const src = await readFile(file, 'utf8');
  const re = /from\s+['"](\.{1,2}\/[^'"]+\.js)['"]/g;
  for (const match of src.matchAll(re)) {
    const target = path.resolve(path.dirname(file), match[1]);
    try { await access(target); } catch { console.error(`Missing import: ${path.relative(process.cwd(), file)} -> ${match[1]}`); failures++; }
  }
}
console.log(`Scanned ${jsFiles.length} JavaScript modules for relative import targets.`);
if (failures) process.exitCode = 1; else console.log('All relative import targets exist.');
