/**
 * Stage 3+ Callback Query Handler
 */

import { api } from 'sdk';
import { getOrCreateUser, getUserByTelegramId } from '../lib/users.js';
import { isOwner } from '../lib/permissions.js';
import { claimDaily } from '../lib/economy.js';
import {
  getOwnedShinobiIds, getEquippedShinobiId, equipShinobi,
  formatOwnedList, formatStorePage,
} from '../lib/shinobi.js';
import { startPatrol, completeDuePatrols } from '../lib/patrol.js';
import { getShinobi } from '../lib/shinobiData.js';
import { esc, coins, userTag, HR, nowUnix } from '../lib/format.js';
import { mainMenuKeyboard, backToMenuKeyboard } from '../lib/keyboards.js';
import { BOT_NAME } from '../lib/config.js';

export default async function (callbackQuery) {
  if (!callbackQuery?.from || !callbackQuery?.message) return;

  const cq = callbackQuery;
  const data = cq.data || '';
  const chatId = cq.message.chat.id;
  const messageId = cq.message.message_id;
  const from = cq.from;
  const uid = String(from.id);

  try { await api.answerCallbackQuery({ callback_query_id: cq.id }); } catch (_) {}

  try { await completeDuePatrols(uid); } catch (_) {}

  let user;
  try { user = await getOrCreateUser(from); } catch (e) { console.error(e); return; }

  async function edit(text, markup = backToMenuKeyboard()) {
    try {
      await api.editMessageText({
        chat_id: chatId, message_id: messageId,
        text, parse_mode: 'HTML', reply_markup: markup,
      });
    } catch (e) {
      // message not modified or too old — ignore
    }
  }

  if (data === 'main_menu' || data === 'help_home') {
    await edit(
      `🏯 <b>${BOT_NAME}</b>\n${HR}\nChoose an option or type a command.`,
      mainMenuKeyboard()
    );
    return;
  }

  if (data === 'balance') {
    const u = await getUserByTelegramId(uid);
    await edit(`${userTag(from)}, balance: <b>${coins(u?.balance || 0)}</b> · Chakra: <b>${u?.chakra || 0}</b>`);
    return;
  }

  if (data === 'profile') {
    const u = await getUserByTelegramId(uid);
    const owned = await getOwnedShinobiIds(uid);
    const eqId = await getEquippedShinobiId(uid);
    const eq = eqId ? getShinobi(eqId) : null;
    const lines = [
      `👤 <b>Profile</b>`, HR,
      `Name: ${esc(u.name)}`,
      u.username ? `Username: @${esc(u.username)}` : null,
      `Balance: <b>${coins(u.balance)}</b>`,
      `Chakra: <b>${u.chakra || 0}</b>`,
      eq ? `Equipped: ${eq.emoji} ${esc(eq.name)}` : 'Equipped: none',
      `Shinobis owned: ${owned.length}`,
      isOwner(from.id) ? `Role: <b>Owner</b>` : null,
    ].filter(Boolean).join('\n');
    await edit(lines);
    return;
  }

  if (data === 'daily') {
    const res = await claimDaily(from);
    if (!res.ok) {
      await edit(`${userTag(from)}, already claimed today.`);
      return;
    }
    const bonus = res.sakuraBonus ? '\n🌸 Sakura bonus!' : '';
    await edit(`🎁 Claimed! +${coins(res.coins)} · +${res.chakra} ⚡${bonus}\nBalance: <b>${coins(res.user.balance)}</b>`);
    return;
  }

  if (data === 'shinobis') {
    const owned = await getOwnedShinobiIds(uid);
    const eqId = await getEquippedShinobiId(uid);
    await edit(`🥷 <b>Your Shinobis</b>\n${HR}\n${formatOwnedList(owned, eqId)}\n\nUse /equip ID`);
    return;
  }

  if (data === 'shinobi_store') {
    await edit(`🏪 <b>Shinobi Store</b>\n${HR}\n${formatStorePage()}`);
    return;
  }

  if (data === 'pets_help') {
    await edit('🐾 <b>Pet System</b>\n\n/pets — view your pets\n/buy_pet axofly\n/buy_pet capycorn\n/equip_pet axofly');
    return;
  }

  if (data === 'patrol') {
    const res = await startPatrol(uid, chatId);
    if (!res.ok) {
      if (res.reason === 'busy') {
        const left = Math.max(0, res.dueAt - nowUnix());
        await edit(`Already on patrol. ~${Math.ceil(left / 60)} min left.`);
      } else if (res.reason === 'recovery') {
        const left = Math.max(0, res.until - nowUnix());
        await edit(`Recovering. ~${Math.ceil(left / 60)} min left.`);
      } else if (res.reason === 'no_shinobi') {
        await edit('Equip a shinobi first.');
      } else {
        await edit('Cannot start patrol.');
      }
      return;
    }
    await edit(`🚶 ${res.shinobi.emoji} <b>${esc(res.shinobi.name)}</b> on patrol!\n⏳ ${res.durationMin} min`);
    return;
  }

  if (data.startsWith('equip:')) {
    const id = parseInt(data.split(':')[1], 10);
    const res = await equipShinobi(uid, id);
    if (!res.ok) {
      await edit('You do not own that shinobi.');
      return;
    }
    const s = getShinobi(id);
    await edit(`✅ Equipped ${s.emoji} <b>${esc(s.name)}</b>`);
    return;
  }
}
