/**
 * Stage 3+ Message Handler
 * Commands: /start /awwsheesh /balance /profile /daily /claim
 *           /shinobis /shinobi_store /equip /buy_shinobi /buy_chakra
 *           /patrol /economy (owner)
 */

import { api } from 'sdk';
import { getOrCreateUser, getUserByTelegramId } from '../lib/users.js';
import { isOwner, isEconomyEnabled, setEconomyEnabled } from '../lib/permissions.js';
import { claimDaily } from '../lib/economy.js';
import {
  getOwnedShinobiIds, getEquippedShinobiId, equipShinobi,
  purchaseShinobi, purchaseChakra, formatOwnedList, formatStorePage,
} from '../lib/shinobi.js';
import { startPatrol, completeDuePatrols, getActivePatrol } from '../lib/patrol.js';
import { getShinobi } from '../lib/shinobiData.js';
import { esc, coins, userTag, HR, nowUnix } from '../lib/format.js';
import { mainMenuKeyboard } from '../lib/keyboards.js';
import { BOT_NAME, PATROL_DURATION_MINUTES } from '../lib/config.js';
import { handlePetCommands, handleCombatCommands } from '../lib/extraCommands.js';

export default async function (message) {
  if (!message?.chat || !message?.from) return;
  if (message.chat.type === 'channel') return;

  const text = (message.text || '').trim();
  if (!text) return;

  const chatId = message.chat.id;
  const from = message.from;
  const uid = String(from.id);

  // Complete any due patrols for this user on every interaction
  try { await completeDuePatrols(uid); } catch (e) { console.error('patrol complete', e); }

  let user;
  try {
    user = await getOrCreateUser(from);
  } catch (err) {
    console.error('getOrCreateUser', err);
    await api.sendMessage({ chat_id: chatId, text: '⚠️ Registration error. Try again.' });
    return;
  }

  const parts = text.split(/\s+/);
  const cmd = parts[0].toLowerCase().split('@')[0];

  // Economy gate for groups
  const economyCmds = ['/daily', '/claim', '/patrol', '/buy_shinobi', '/buy_chakra', '/buy_pet', '/kill', '/rob', '/mission'];
  if (economyCmds.includes(cmd) && chatId < 0) {
    const on = await isEconomyEnabled(chatId);
    if (!on) {
      await api.sendMessage({ chat_id: chatId, text: '🚫 Economy is disabled in this group.' });
      return;
    }
  }

  // ── /start ──────────────────────────────────────────────────────────────
  if (cmd === '/start') {
    const welcome = [
      `🥷 Welcome to <b>${BOT_NAME}</b>!`,
      HR,
      `You are registered as ${userTag(from)}.`,
      `Balance: <b>${coins(user.balance)}</b>`,
      ``,
      `You received a free Starter Shinobi 🥷`,
      `Type <code>/awwsheesh</code> for the menu.`,
    ].join('\n');
    await api.sendMessage({
      chat_id: chatId, text: welcome, parse_mode: 'HTML',
      reply_markup: mainMenuKeyboard(), disable_web_page_preview: true,
    });
    return;
  }

  // ── /awwsheesh ──────────────────────────────────────────────────────────
  if (cmd === '/awwsheesh' || cmd === '/menu') {
    await api.sendMessage({
      chat_id: chatId,
      text: `🏯 <b>${BOT_NAME}</b>\n${HR}\nChoose an option or type a command.`,
      parse_mode: 'HTML', reply_markup: mainMenuKeyboard(),
    });
    return;
  }

  // ── /balance ────────────────────────────────────────────────────────────
  if (cmd === '/balance' || cmd === '/bal') {
    const u = await getUserByTelegramId(uid);
    await api.sendMessage({
      chat_id: chatId,
      text: `${userTag(from)}, balance: <b>${coins(u?.balance || 0)}</b> · Chakra: <b>${u?.chakra || 0}</b>`,
      parse_mode: 'HTML',
    });
    return;
  }

  // ── /profile ────────────────────────────────────────────────────────────
  if (cmd === '/profile') {
    const u = await getUserByTelegramId(uid);
    const owned = await getOwnedShinobiIds(uid);
    const eqId = await getEquippedShinobiId(uid);
    const eq = eqId ? getShinobi(eqId) : null;
    const lines = [
      `👤 <b>Profile</b>`, HR,
      `Name: ${esc(u.name)}`,
      u.username ? `Username: @${esc(u.username)}` : null,
      `Balance: <b>${coins(u.balance)}</b>`,
      `Chakra: <b>${u.chakra || 0}</b>`,
      eq ? `Equipped: ${eq.emoji} ${esc(eq.name)}` : 'Equipped: none',
      `Shinobis owned: ${owned.length}`,
      isOwner(from.id) ? `Role: <b>Owner</b>` : null,
    ].filter(Boolean).join('\n');
    await api.sendMessage({ chat_id: chatId, text: lines, parse_mode: 'HTML' });
    return;
  }

  // ── /daily /claim ───────────────────────────────────────────────────────
  if (cmd === '/daily' || cmd === '/claim') {
    const res = await claimDaily(from);
    if (!res.ok) {
      await api.sendMessage({
        chat_id: chatId,
        text: `${userTag(from)}, you already claimed today. Come back tomorrow!`,
        parse_mode: 'HTML',
      });
      return;
    }
    const bonus = res.sakuraBonus ? '\n🌸 Sakura bonus applied!' : '';
    await api.sendMessage({
      chat_id: chatId,
      text: `🎁 ${userTag(from)} claimed daily!\n+${coins(res.coins)} · +${res.chakra} ⚡${bonus}\n\nNew balance: <b>${coins(res.user.balance)}</b>`,
      parse_mode: 'HTML',
    });
    return;
  }

  // ── /shinobis ───────────────────────────────────────────────────────────
  if (cmd === '/shinobis') {
    const owned = await getOwnedShinobiIds(uid);
    const eqId = await getEquippedShinobiId(uid);
    const body = `🥷 <b>Your Shinobis</b>\n${HR}\n${formatOwnedList(owned, eqId)}\n\nEquip with <code>/equip ID</code>`;
    await api.sendMessage({ chat_id: chatId, text: body, parse_mode: 'HTML' });
    return;
  }

  // ── /shinobi_store ──────────────────────────────────────────────────────
  if (cmd === '/shinobi_store') {
    const body = `🏪 <b>Shinobi Store</b>\n${HR}\n${formatStorePage()}`;
    await api.sendMessage({ chat_id: chatId, text: body, parse_mode: 'HTML' });
    return;
  }

  // ── /equip <id> ─────────────────────────────────────────────────────────
  if (cmd === '/equip') {
    const id = parseInt(parts[1], 10);
    if (!id) {
      await api.sendMessage({ chat_id: chatId, text: 'Usage: /equip <shinobi_id>' });
      return;
    }
    const res = await equipShinobi(uid, id);
    if (!res.ok) {
      await api.sendMessage({ chat_id: chatId, text: '❌ You do not own that shinobi.' });
      return;
    }
    const s = getShinobi(id);
    await api.sendMessage({
      chat_id: chatId,
      text: `✅ Equipped ${s.emoji} <b>${esc(s.name)}</b>`,
      parse_mode: 'HTML',
    });
    return;
  }

  // ── /buy_shinobi <id> ───────────────────────────────────────────────────
  if (cmd === '/buy_shinobi') {
    const id = parseInt(parts[1], 10);
    if (!id) {
      await api.sendMessage({ chat_id: chatId, text: 'Usage: /buy_shinobi <id>\nSee /shinobi_store' });
      return;
    }
    const res = await purchaseShinobi(uid, id);
    if (!res.ok) {
      if (res.reason === 'already') {
        await api.sendMessage({ chat_id: chatId, text: 'You already own this shinobi.' });
      } else if (res.reason === 'funds') {
        await api.sendMessage({
          chat_id: chatId,
          text: `Not enough coins. Need ${coins(res.need)}, have ${coins(res.have)}.`,
          parse_mode: 'HTML',
        });
      } else if (res.reason === 'storage') {
        await api.sendMessage({ chat_id: chatId, text: 'Purchase could not be saved. No charge was kept; please try again.' });
      } else {
        await api.sendMessage({ chat_id: chatId, text: 'Invalid item.' });
      }
      return;
    }
    await api.sendMessage({
      chat_id: chatId,
      text: `✅ Purchased ${res.shinobi.emoji} <b>${esc(res.shinobi.name)}</b> for ${coins(res.price)}!`,
      parse_mode: 'HTML',
    });
    return;
  }

  // ── /buy_chakra ─────────────────────────────────────────────────────────
  if (cmd === '/buy_chakra') {
    const res = await purchaseChakra(uid);
    if (!res.ok) {
      await api.sendMessage({
        chat_id: chatId,
        text: `Not enough coins. Need ${coins(res.need)}, have ${coins(res.have)}.`,
        parse_mode: 'HTML',
      });
      return;
    }
    await api.sendMessage({
      chat_id: chatId,
      text: `⚡ +${res.amount} Chakra for ${coins(res.price)}`,
      parse_mode: 'HTML',
    });
    return;
  }

  // ── /patrol ─────────────────────────────────────────────────────────────
  if (cmd === '/patrol') {
    const res = await startPatrol(uid, chatId);
    if (!res.ok) {
      if (res.reason === 'no_shinobi') {
        await api.sendMessage({ chat_id: chatId, text: 'Equip a shinobi first (/equip).' });
      } else if (res.reason === 'cannot_patrol') {
        await api.sendMessage({ chat_id: chatId, text: `${res.name} cannot patrol.` });
      } else if (res.reason === 'busy') {
        const left = Math.max(0, res.dueAt - nowUnix());
        const mins = Math.ceil(left / 60);
        await api.sendMessage({ chat_id: chatId, text: `Already on patrol. ~${mins} min left.` });
      } else if (res.reason === 'recovery') {
        const left = Math.max(0, res.until - nowUnix());
        const mins = Math.ceil(left / 60);
        await api.sendMessage({ chat_id: chatId, text: `Shinobi is recovering. ~${mins} min left.` });
      } else {
        await api.sendMessage({ chat_id: chatId, text: 'Cannot start patrol.' });
      }
      return;
    }
    await api.sendMessage({
      chat_id: chatId,
      text: `🚶 ${res.shinobi.emoji} <b>${esc(res.shinobi.name)}</b> sent on patrol!\n⏳ Duration: ${res.durationMin} min\nReward will be granted automatically when time is up (or on next command).`,
      parse_mode: 'HTML',
    });
    return;
  }

  // ── /economy (owner toggle in groups) ───────────────────────────────────
  if (cmd === '/economy' && chatId < 0) {
    if (!isOwner(from.id)) {
      await api.sendMessage({ chat_id: chatId, text: 'Owner only.' });
      return;
    }
    const on = await isEconomyEnabled(chatId);
    await setEconomyEnabled(chatId, !on);
    await api.sendMessage({
      chat_id: chatId,
      text: `Economy is now <b>${!on ? 'ENABLED' : 'DISABLED'}</b> in this group.`,
      parse_mode: 'HTML',
    });
    return;
  }

  // ── Pets and combat commands ─────────────────────────────────────────────
  if (await handlePetCommands(cmd, parts, from, chatId, uid)) return;
  if (await handleCombatCommands(cmd, parts, from, chatId, uid, message)) return;
}
