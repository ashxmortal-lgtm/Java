/**
 * Unified FROZEN bot schema — fresh Telegram Serverless database.
 * No legacy database or records are required.
 *
 * After upload: npx tgcloud push && npx tgcloud migrate
 */

import { table, integer, text, boolean, sql, index, uniqueIndex } from 'sdk/db';

// ─── USERS (keep existing + foundation columns) ─────────────────────────────
export const users = table('users', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  telegramId:  text('telegram_id').notNull().unique(),
  name:        text('name').notNull(),
  username:    text('username'),
  balance:     integer('balance').notNull().default(0),
  chakra:      integer('chakra').notNull().default(0),
  lastDaily:   text('last_daily'),          // YYYY-MM-DD IST
  createdAt:   integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
  updatedAt:   integer('updated_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
});

// ─── GROUP SETTINGS ─────────────────────────────────────────────────────────
export const groupSettings = table('group_settings', {
  chatId:          integer('chat_id').primaryKey(),
  economyEnabled:  integer('economy_enabled').notNull().default(1),
  title:           text('title'),
});

// ─── OWNED SHINOBIS ─────────────────────────────────────────────────────────
export const ownedShinobis = table('owned_shinobis', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  userId:      text('user_id').notNull(),       // telegram_id
  shinobiId:   integer('shinobi_id').notNull(),
  obtainedAt:  integer('obtained_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
}, (t) => ({
  uq: uniqueIndex('uidx_owned_shinobi_user_item').on(t.userId, t.shinobiId),
}));

// ─── EQUIPPED SHINOBI ───────────────────────────────────────────────────────
export const equippedShinobi = table('equipped_shinobi', {
  userId:     text('user_id').primaryKey(),
  shinobiId:  integer('shinobi_id').notNull(),
});

// ─── SHINOBI XP / RANK ──────────────────────────────────────────────────────
export const shinobiXp = table('shinobi_xp', {
  userId:  text('user_id').primaryKey(),
  xp:      integer('xp').notNull().default(0),
});

// ─── PATROLS (active + pending completion) ──────────────────────────────────
export const shinobiPatrols = table('shinobi_patrols', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  userId:      text('user_id').notNull(),
  shinobiId:   integer('shinobi_id').notNull(),
  chatId:      integer('chat_id'),
  startedAt:   integer('started_at', { mode: 'timestamp' }).notNull(),
  dueAt:       integer('due_at', { mode: 'timestamp' }).notNull(),
  completed:   integer('completed').notNull().default(0),
  reward:      integer('reward').default(0),
  claimed:     integer('claimed').notNull().default(0),
}, (t) => ({
  idxUser: index('idx_patrol_user').on(t.userId),
  idxDue:  index('idx_patrol_due').on(t.dueAt),
}));

// ─── PATROL RECOVERY / EXHAUSTION ───────────────────────────────────────────
export const shinobiPatrolRecovery = table('shinobi_patrol_recovery', {
  userId:              text('user_id').notNull(),
  shinobiId:           integer('shinobi_id').notNull(),
  consecutivePatrols:  integer('consecutive_patrols').notNull().default(0),
  recoveryUntil:       integer('recovery_until', { mode: 'timestamp' }),
}, (t) => ({
  pk: uniqueIndex('uidx_patrol_recovery_user_shinobi').on(t.userId, t.shinobiId),
}));

// ─── MISSIONS ───────────────────────────────────────────────────────────────
export const shinobiMissions = table('shinobi_missions', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  userId:      text('user_id').notNull(),
  shinobiId:   integer('shinobi_id').notNull(),
  chatId:      integer('chat_id'),
  startedAt:   integer('started_at', { mode: 'timestamp' }).notNull(),
  dueAt:       integer('due_at', { mode: 'timestamp' }).notNull(),
  completed:   integer('completed').notNull().default(0),
  reward:      integer('reward').default(0),
  claimed:     integer('claimed').notNull().default(0),
}, (t) => ({
  idxUser: index('idx_mission_user').on(t.userId),
  idxDue:  index('idx_mission_due').on(t.dueAt),
}));

// ─── ITACHI PROGRESS ────────────────────────────────────────────────────────
export const itachiProgress = table('itachi_progress', {
  userId:     text('user_id').primaryKey(),
  killCount:  integer('kill_count').notNull().default(0),
});

// ─── JIRAIYA DISCOVERY ──────────────────────────────────────────────────────
export const jiraiyaDiscovery = table('jiraiya_discovery', {
  userId:        text('user_id').primaryKey(),
  patrolCount:   integer('patrol_count').notNull().default(0),
  discovered:    integer('discovered').notNull().default(0),
});

// ─── PROTECTION ─────────────────────────────────────────────────────────────
export const shinobiProtection = table('shinobi_protection', {
  userId:       text('user_id').primaryKey(),
  until:        integer('until', { mode: 'timestamp' }).notNull(),
  cooldownUntil: integer('cooldown_until', { mode: 'timestamp' }),
});

// ─── COMBAT COOLDOWNS (kill/rob per target) ─────────────────────────────────
export const combatCooldowns = table('combat_cooldowns', {
  attackerId:  text('attacker_id').notNull(),
  targetId:    text('target_id').notNull(),
  until:       integer('until', { mode: 'timestamp' }).notNull(),
}, (t) => ({
  idx: uniqueIndex('uidx_combat_cd_attacker_target').on(t.attackerId, t.targetId),
}));

// ─── STARTER NOTICE (so we only grant once) ─────────────────────────────────
export const starterShinobiNotice = table('starter_shinobi_notice', {
  userId:  text('user_id').primaryKey(),
  granted: integer('granted').notNull().default(1),
});


// ─── Additional systems: pets, study, hourly quiz, XOXO ─────────────────────
// ─── PETS ───────────────────────────────────────────────────────────────────
export const userPets = table('user_pets', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  userId:      text('user_id').notNull(),
  petId:       text('pet_id').notNull(),          // axofly | capycorn
  level:       integer('level').notNull().default(1),
  energy:      integer('energy').notNull().default(100),
  name:        text('name'),                      // custom nametag
  obtainedAt:  integer('obtained_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
}, (t) => ({
  idx: uniqueIndex('uidx_user_pets_user_pet').on(t.userId, t.petId),
}));

export const equippedPet = table('equipped_pet', {
  userId:  text('user_id').primaryKey(),
  petId:   text('pet_id').notNull(),
});

export const petActivity = table('pet_activity', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  userId:      text('user_id').notNull(),
  petId:       text('pet_id').notNull(),
  activity:    text('activity').notNull(),        // feed|train|play|rest
  startedAt:   integer('started_at', { mode: 'timestamp' }).notNull(),
  dueAt:       integer('due_at', { mode: 'timestamp' }).notNull(),
  completed:   integer('completed').notNull().default(0),
}, (t) => ({
  idx: index('idx_pet_activity').on(t.userId),
}));

// ─── HINATA BYAKUGAN DAILY ──────────────────────────────────────────────────
export const hinataByakugan = table('hinata_byakugan', {
  userId:     text('user_id').primaryKey(),
  lastDate:   text('last_date'),                  // YYYY-MM-DD
  usesToday:  integer('uses_today').notNull().default(0),
});

// ─── STUDY (basic) ──────────────────────────────────────────────────────────
export const studyGoals = table('study_goals', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  userId:      text('user_id').notNull(),
  chatId:      integer('chat_id'),
  goal:        text('goal').notNull(),
  targetMin:   integer('target_min').default(0),
  doneMin:     integer('done_min').default(0),
  createdAt:   integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
});

export const todos = table('todos', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  userId:      text('user_id').notNull(),
  chatId:      integer('chat_id'),
  text:        text('text').notNull(),
  done:        integer('done').notNull().default(0),
  dueAt:       integer('due_at', { mode: 'timestamp' }),
  createdAt:   integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
});

// ─── HOURLY QUIZ (structure) ────────────────────────────────────────────────
export const hourlyGroupSettings = table('hourly_group_settings', {
  chatId:     integer('chat_id').primaryKey(),
  enabled:    integer('enabled').notNull().default(0),
  hour:       integer('hour').default(21),        // 9 PM IST default
});

export const hourlyQuestions = table('hourly_questions', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  question:    text('question').notNull(),
  answer:      text('answer').notNull(),
  topic:       text('topic'),
  active:      integer('active').notNull().default(1),
});

export const hourlyPosts = table('hourly_posts', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  chatId:      integer('chat_id').notNull(),
  questionId:  integer('question_id').notNull(),
  messageId:   integer('message_id'),
  postedAt:    integer('posted_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
  closed:      integer('closed').notNull().default(0),
});

export const hourlyAnswers = table('hourly_answers', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  postId:      integer('post_id').notNull(),
  userId:      text('user_id').notNull(),
  correct:     integer('correct').notNull().default(0),
  reward:      integer('reward').default(0),
  answeredAt:  integer('answered_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
});

// ─── XOXO (structure) ───────────────────────────────────────────────────────
export const xoxoLobbies = table('xoxo_lobbies', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  chatId:      integer('chat_id').notNull(),
  hostId:      text('host_id').notNull(),
  stake:       integer('stake').notNull().default(500),
  status:      text('status').notNull().default('open'), // open|playing|done
  createdAt:   integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
});

export const xoxoMatches = table('xoxo_matches', {
  id:          integer('id').primaryKey({ autoIncrement: true }),
  lobbyId:     integer('lobby_id').notNull(),
  player1:     text('player1').notNull(),
  player2:     text('player2').notNull(),
  board:       text('board').notNull().default('_________'), // 9 chars
  turn:        text('turn').notNull(),
  stake:       integer('stake').notNull(),
  winner:      text('winner'),
  status:      text('status').notNull().default('playing'),
});

